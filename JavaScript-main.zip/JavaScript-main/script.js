  
function help() {

    textbox('Type here')
}
alert("Thankyou Your information is Recorded...")